import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import GameSelectionCard from './components/GameSelectionCard';
import AmountSelector from './components/AmountSelector';
import UserInfoForm from './components/UserInfoForm';
import PaymentMethodSelector from './components/PaymentMethodSelector';
import OrderSummary from './components/OrderSummary';
import CheckoutProgress from './components/CheckoutProgress';
import WhatsAppConfirmation from './components/WhatsAppConfirmation';

const PaymentCheckout = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState([]);
  const [selectedGame, setSelectedGame] = useState(null);
  const [selectedAmount, setSelectedAmount] = useState(null);
  const [userInfo, setUserInfo] = useState({
    userId: '',
    server: '',
    username: '',
    whatsapp: '',
    email: '',
    isValidated: false
  });
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Auto-advance steps based on completed data
  useEffect(() => {
    const newCompletedSteps = [];
    let nextStep = 1;

    if (selectedGame) {
      newCompletedSteps?.push(1);
      nextStep = 2;
    }
    if (selectedAmount) {
      newCompletedSteps?.push(2);
      nextStep = 3;
    }
    if (userInfo?.isValidated && userInfo?.whatsapp) {
      newCompletedSteps?.push(3);
      nextStep = 4;
    }
    if (selectedPaymentMethod) {
      newCompletedSteps?.push(4);
      nextStep = 5;
    }

    setCompletedSteps(newCompletedSteps);
    if (nextStep > currentStep) {
      setCurrentStep(nextStep);
    }
  }, [selectedGame, selectedAmount, userInfo, selectedPaymentMethod, currentStep]);

  const handleGameChange = (game) => {
    setSelectedGame(game);
    if (!game) {
      setSelectedAmount(null);
      setCurrentStep(1);
    }
  };

  const handleAmountChange = (amount) => {
    setSelectedAmount(amount);
  };

  const handleUserInfoChange = (info) => {
    setUserInfo(info);
  };

  const handlePaymentMethodChange = (method) => {
    setSelectedPaymentMethod(method);
  };

  const handleProceedToPayment = async () => {
    if (!selectedGame || !selectedAmount || !userInfo?.isValidated || !selectedPaymentMethod) {
      return;
    }

    setIsProcessing(true);
    
    // Simulate processing delay
    setTimeout(() => {
      setIsProcessing(false);
      setShowConfirmation(true);
      setCurrentStep(5);
      setCompletedSteps([1, 2, 3, 4, 5]);
    }, 2000);
  };

  const handleConfirmOrder = () => {
    // This would typically redirect to WhatsApp or show success message
    console.log('Order confirmed, redirecting to WhatsApp...');
  };

  const canProceed = selectedGame && selectedAmount && userInfo?.isValidated && userInfo?.whatsapp && selectedPaymentMethod;

  const orderData = {
    game: selectedGame,
    amount: selectedAmount,
    userInfo: userInfo,
    paymentMethod: selectedPaymentMethod
  };

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <CheckoutProgress currentStep={currentStep} completedSteps={completedSteps} />
            <WhatsAppConfirmation 
              orderData={orderData}
              onConfirm={handleConfirmOrder}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-text-primary mb-2">
              Checkout Pembayaran
            </h1>
            <p className="text-text-secondary">
              Lengkapi informasi di bawah untuk melanjutkan top-up game Anda
            </p>
          </div>

          {/* Progress Indicator */}
          <CheckoutProgress currentStep={currentStep} completedSteps={completedSteps} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Step 1: Game Selection */}
              <GameSelectionCard
                selectedGame={selectedGame}
                onGameChange={handleGameChange}
              />

              {/* Step 2: Amount Selection */}
              {selectedGame && (
                <AmountSelector
                  selectedAmount={selectedAmount}
                  onAmountChange={handleAmountChange}
                  gameId={selectedGame?.id}
                />
              )}

              {/* Step 3: User Information */}
              {selectedGame && selectedAmount && (
                <UserInfoForm
                  gameId={selectedGame?.id}
                  userInfo={userInfo}
                  onUserInfoChange={handleUserInfoChange}
                />
              )}

              {/* Step 4: Payment Method */}
              {selectedGame && selectedAmount && userInfo?.isValidated && (
                <PaymentMethodSelector
                  selectedMethod={selectedPaymentMethod}
                  onMethodChange={handlePaymentMethodChange}
                />
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-6">
                <Button
                  variant="outline"
                  iconName="ArrowLeft"
                  iconPosition="left"
                  onClick={() => window.history?.back()}
                  className="sm:w-auto"
                >
                  Kembali
                </Button>

                <Button
                  variant="default"
                  iconName="ArrowRight"
                  iconPosition="right"
                  loading={isProcessing}
                  disabled={!canProceed}
                  onClick={handleProceedToPayment}
                  className="flex-1 sm:flex-none bg-primary hover:bg-primary/90"
                >
                  {isProcessing ? 'Memproses...' : 'Lanjut ke WhatsApp'}
                </Button>
              </div>
            </div>

            {/* Sidebar - Order Summary */}
            <div className="lg:col-span-1">
              <OrderSummary
                selectedGame={selectedGame}
                selectedAmount={selectedAmount}
                selectedMethod={selectedPaymentMethod}
                userInfo={userInfo}
              />
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="w-12 h-12 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Shield" size={24} className="text-success" />
              </div>
              <h3 className="font-semibold text-text-primary mb-2">100% Aman</h3>
              <p className="text-sm text-text-secondary">
                Transaksi dilindungi dengan enkripsi SSL dan sistem keamanan berlapis
              </p>
            </div>

            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Zap" size={24} className="text-primary" />
              </div>
              <h3 className="font-semibold text-text-primary mb-2">Proses Cepat</h3>
              <p className="text-sm text-text-secondary">
                Top-up otomatis dalam 1-10 menit setelah pembayaran dikonfirmasi
              </p>
            </div>

            <div className="text-center p-6 bg-card rounded-lg border border-border">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Headphones" size={24} className="text-accent" />
              </div>
              <h3 className="font-semibold text-text-primary mb-2">Support 24/7</h3>
              <p className="text-sm text-text-secondary">
                Tim customer service siap membantu Anda kapan saja via WhatsApp
              </p>
            </div>
          </div>

          {/* Customer Testimonials */}
          <div className="mt-12 bg-card rounded-lg border border-border p-8">
            <h3 className="text-xl font-bold text-text-primary text-center mb-8">
              Apa Kata Pelanggan Kami
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  name: "Rizki Pratama",
                  game: "Mobile Legends",
                  rating: 5,
                  comment: "Proses cepat banget! Diamonds langsung masuk dalam 2 menit. Recommended!"
                },
                {
                  name: "Sari Dewi",
                  game: "Free Fire",
                  rating: 5,
                  comment: "Admin responsif, harga murah, dan pelayanan memuaskan. Pasti langganan di sini!"
                },
                {
                  name: "Ahmad Fauzi",
                  game: "PUBG Mobile",
                  rating: 5,
                  comment: "Sudah 5x top-up di sini, selalu aman dan cepat. Customer service juga ramah."
                }
              ]?.map((testimonial, index) => (
                <div key={index} className="p-4 bg-muted rounded-lg">
                  <div className="flex items-center space-x-1 mb-2">
                    {[...Array(testimonial?.rating)]?.map((_, i) => (
                      <Icon key={i} name="Star" size={14} className="text-warning fill-current" />
                    ))}
                  </div>
                  <p className="text-sm text-text-secondary mb-3">"{testimonial?.comment}"</p>
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-text-primary">{testimonial?.name}</span>
                    <span className="text-xs text-text-secondary">{testimonial?.game}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentCheckout;