import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import CategoryFilter from './components/CategoryFilter';
import SearchAndSort from './components/SearchAndSort';
import PromotionalBanner from './components/PromotionalBanner';
import GameGrid from './components/GameGrid';
import QuickAddModal from './components/QuickAddModal';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const GameCatalog = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popularity');
  const [isLoading, setIsLoading] = useState(true);
  const [quickAddModal, setQuickAddModal] = useState({
    isOpen: false,
    game: null,
    denomination: null
  });

  // Mock data for categories
  const categories = [
    { id: 'all', name: 'Semua Game', icon: 'Grid3X3', count: 24 },
    { id: 'moba', name: 'MOBA', icon: 'Sword', count: 6 },
    { id: 'battle-royale', name: 'Battle Royale', icon: 'Target', count: 5 },
    { id: 'rpg', name: 'RPG', icon: 'Shield', count: 7 },
    { id: 'casual', name: 'Casual', icon: 'Heart', count: 6 }
  ];

  // Mock data for promotions
  const promotions = [
    {
      id: 1,
      badge: 'Promo Spesial',
      title: 'Diskon 20% Semua Game',
      description: 'Dapatkan diskon hingga 20% untuk top up game favorit kamu!',
      discount: '20% OFF',
      validUntil: '31 Desember 2024',
      usedCount: '2.847',
      image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop'
    },
    {
      id: 2,
      title: 'Bonus Diamond',
      description: 'Bonus 10% diamond untuk Mobile Legends',
      discount: '+10%',
      icon: 'Gift'
    },
    {
      id: 3,
      title: 'Cashback UC',
      description: 'Cashback 5% untuk PUBG Mobile',
      discount: '5% Back',
      icon: 'ArrowLeft'
    },
    {
      id: 4,
      title: 'Free Fire Fest',
      description: 'Promo khusus Free Fire bulan ini',
      discount: '15% OFF',
      icon: 'Flame'
    }
  ];

  // Mock data for games
  const games = [
    {
      id: 1,
      name: 'Mobile Legends: Bang Bang',
      description: 'Game MOBA terpopuler di Indonesia dengan jutaan pemain aktif setiap hari.',
      category: 'moba',
      image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop',
      rating: 4.8,
      playerCount: '100M+',
      minPrice: 5000,
      maxPrice: 500000,
      processingTime: 'Instan dalam 5 menit',
      isPromotional: true,
      promotionalText: 'POPULER',
      popularity: 100,
      quickDenominations: [
        { value: 86, label: '86 Diamond', price: 20000, bonus: '+4 Diamond' },
        { value: 172, label: '172 Diamond', price: 40000, bonus: '+8 Diamond' },
        { value: 257, label: '257 Diamond', price: 60000, bonus: '+12 Diamond' }
      ]
    },
    {
      id: 2,
      name: 'Free Fire',
      description: 'Battle royale game dengan gameplay cepat dan seru untuk mobile.',
      category: 'battle-royale',
      image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&h=300&fit=crop',
      rating: 4.6,
      playerCount: '80M+',
      minPrice: 5000,
      maxPrice: 300000,
      processingTime: 'Instan dalam 3 menit',
      isPromotional: true,
      promotionalText: 'PROMO',
      popularity: 95,
      quickDenominations: [
        { value: 70, label: '70 Diamond', price: 10000 },
        { value: 140, label: '140 Diamond', price: 20000 },
        { value: 355, label: '355 Diamond', price: 50000 }
      ]
    },
    {
      id: 3,
      name: 'PUBG Mobile',
      description: 'Battle royale realistis dengan grafik memukau dan gameplay kompetitif.',
      category: 'battle-royale',
      image: 'https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=400&h=300&fit=crop',
      rating: 4.7,
      playerCount: '75M+',
      minPrice: 16000,
      maxPrice: 800000,
      processingTime: 'Instan dalam 5 menit',
      isPromotional: false,
      popularity: 90,
      quickDenominations: [
        { value: 60, label: '60 UC', price: 16000 },
        { value: 325, label: '325 UC', price: 80000 },
        { value: 660, label: '660 UC', price: 160000 }
      ]
    },
    {
      id: 4,
      name: 'Genshin Impact',
      description: 'RPG open-world dengan visual anime yang memukau dan cerita mendalam.',
      category: 'rpg',
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
      rating: 4.9,
      playerCount: '60M+',
      minPrice: 16000,
      maxPrice: 1600000,
      processingTime: 'Instan dalam 10 menit',
      isPromotional: false,
      popularity: 85,
      quickDenominations: [
        { value: 60, label: '60 Genesis Crystal', price: 16000 },
        { value: 300, label: '300 Genesis Crystal', price: 79000 },
        { value: 980, label: '980 Genesis Crystal', price: 249000 }
      ]
    },
    {
      id: 5,
      name: 'Arena of Valor',
      description: 'MOBA 5v5 dengan hero-hero legendaris dan pertarungan epik.',
      category: 'moba',
      image: 'https://images.unsplash.com/photo-1556438064-2d7646166914?w=400&h=300&fit=crop',
      rating: 4.5,
      playerCount: '50M+',
      minPrice: 12000,
      maxPrice: 400000,
      processingTime: 'Instan dalam 5 menit',
      isPromotional: false,
      popularity: 80,
      quickDenominations: [
        { value: 90, label: '90 Voucher', price: 12000 },
        { value: 180, label: '180 Voucher', price: 24000 },
        { value: 450, label: '450 Voucher', price: 60000 }
      ]
    },
    {
      id: 6,
      name: 'Honkai Star Rail',
      description: 'RPG turn-based dengan grafik 3D yang menakjubkan dari miHoYo.',
      category: 'rpg',
      image: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=400&h=300&fit=crop',
      rating: 4.8,
      playerCount: '40M+',
      minPrice: 16000,
      maxPrice: 1600000,
      processingTime: 'Instan dalam 10 menit',
      isPromotional: true,
      promotionalText: 'BARU',
      popularity: 75,
      quickDenominations: [
        { value: 60, label: '60 Oneiric Shard', price: 16000 },
        { value: 300, label: '300 Oneiric Shard', price: 79000 },
        { value: 980, label: '980 Oneiric Shard', price: 249000 }
      ]
    },
    {
      id: 7,
      name: 'Call of Duty Mobile',
      description: 'FPS mobile dengan mode Battle Royale dan Multiplayer yang seru.',
      category: 'battle-royale',
      image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop',
      rating: 4.6,
      playerCount: '70M+',
      minPrice: 15000,
      maxPrice: 500000,
      processingTime: 'Instan dalam 5 menit',
      isPromotional: false,
      popularity: 70,
      quickDenominations: [
        { value: 80, label: '80 CP', price: 15000 },
        { value: 400, label: '400 CP', price: 75000 },
        { value: 800, label: '800 CP', price: 150000 }
      ]
    },
    {
      id: 8,
      name: 'Ragnarok M: Eternal Love',
      description: 'MMORPG klasik dengan sistem guild dan PvP yang kompetitif.',
      category: 'rpg',
      image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&h=300&fit=crop',
      rating: 4.4,
      playerCount: '30M+',
      minPrice: 10000,
      maxPrice: 300000,
      processingTime: 'Instan dalam 5 menit',
      isPromotional: false,
      popularity: 65,
      quickDenominations: [
        { value: 60, label: '60 Big Cat Coin', price: 10000 },
        { value: 300, label: '300 Big Cat Coin', price: 50000 },
        { value: 600, label: '600 Big Cat Coin', price: 100000 }
      ]
    }
  ];

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  // Filter and sort games
  const filteredAndSortedGames = useMemo(() => {
    let filtered = games;

    // Filter by category
    if (activeCategory !== 'all') {
      filtered = filtered?.filter(game => game?.category === activeCategory);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered?.filter(game =>
        game?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        game?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    // Sort games
    const sorted = [...filtered]?.sort((a, b) => {
      switch (sortBy) {
        case 'name-asc':
          return a?.name?.localeCompare(b?.name);
        case 'name-desc':
          return b?.name?.localeCompare(a?.name);
        case 'price-low':
          return a?.minPrice - b?.minPrice;
        case 'price-high':
          return b?.maxPrice - a?.maxPrice;
        case 'rating':
          return b?.rating - a?.rating;
        case 'newest':
          return b?.id - a?.id;
        case 'popularity':
        default:
          return b?.popularity - a?.popularity;
      }
    });

    return sorted;
  }, [games, activeCategory, searchQuery, sortBy]);

  const handleQuickAdd = (game, denomination) => {
    setQuickAddModal({
      isOpen: true,
      game: game,
      denomination: denomination
    });
  };

  const closeQuickAddModal = () => {
    setQuickAddModal({
      isOpen: false,
      game: null,
      denomination: null
    });
  };

  return (
    <>
      <Helmet>
        <title>Katalog Game - Finn Gaming Store</title>
        <meta name="description" content="Jelajahi koleksi lengkap game mobile populer Indonesia. Top up diamond, UC, dan in-game currency dengan harga terbaik dan proses instan." />
        <meta name="keywords" content="game catalog, mobile legends, free fire, pubg mobile, genshin impact, top up game" />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="container mx-auto px-4 py-8">
          {/* Page Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Katalog Game Terlengkap
            </h1>
            <p className="text-lg text-text-secondary max-w-2xl mx-auto">
              Temukan game mobile favorit kamu dan lakukan top up dengan mudah, aman, dan instan
            </p>
          </div>

          {/* Promotional Banner */}
          <PromotionalBanner promotions={promotions} />

          {/* Category Filter */}
          <CategoryFilter
            categories={categories}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
          />

          {/* Search and Sort */}
          <SearchAndSort
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            sortBy={sortBy}
            onSortChange={setSortBy}
            totalGames={games?.length}
            filteredGames={filteredAndSortedGames?.length}
          />

          {/* Game Grid */}
          <GameGrid
            games={filteredAndSortedGames}
            onQuickAdd={handleQuickAdd}
            isLoading={isLoading}
          />

          {/* Load More Button (if needed) */}
          {!isLoading && filteredAndSortedGames?.length > 0 && (
            <div className="text-center mt-12">
              <Button
                variant="outline"
                size="lg"
                iconName="MoreHorizontal"
                iconPosition="left"
                className="min-w-[200px]"
              >
                Muat Lebih Banyak
              </Button>
            </div>
          )}

          {/* Trust Indicators */}
          <div className="mt-16 bg-card rounded-2xl border border-border p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-text-primary mb-2">
                Kenapa Pilih Finn Gaming Store?
              </h2>
              <p className="text-text-secondary">
                Dipercaya oleh jutaan gamer Indonesia
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="Zap" size={32} className="text-primary" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">
                  Proses Instan
                </h3>
                <p className="text-sm text-text-secondary">
                  Top up langsung masuk dalam hitungan menit
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="Shield" size={32} className="text-success" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">
                  100% Aman
                </h3>
                <p className="text-sm text-text-secondary">
                  Transaksi dijamin aman dengan sistem keamanan terdepan
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="Headphones" size={32} className="text-secondary" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">
                  Support 24/7
                </h3>
                <p className="text-sm text-text-secondary">
                  Tim customer service siap membantu kapan saja
                </p>
              </div>
            </div>
          </div>
        </main>

        {/* Quick Add Modal */}
        <QuickAddModal
          isOpen={quickAddModal?.isOpen}
          onClose={closeQuickAddModal}
          game={quickAddModal?.game}
          selectedDenomination={quickAddModal?.denomination}
        />

        {/* WhatsApp Float Button */}
        <div className="fixed bottom-6 right-6 z-40">
          <Button
            variant="default"
            size="icon"
            className="w-14 h-14 rounded-full bg-green-500 hover:bg-green-600 shadow-lg whatsapp-float"
            onClick={() => window.open('https://wa.me/6281234567890', '_blank')}
          >
            <Icon name="MessageCircle" size={24} color="white" />
          </Button>
        </div>
      </div>
    </>
  );
};

export default GameCatalog;