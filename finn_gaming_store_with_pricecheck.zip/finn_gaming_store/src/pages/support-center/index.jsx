import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import FAQSection from './components/FAQSection';
import ContactOptions from './components/ContactOptions';
import KnowledgeBase from './components/KnowledgeBase';
import LiveChatWidget from './components/LiveChatWidget';

const SupportCenter = () => {
  const [activeTab, setActiveTab] = useState('faq');

  const tabs = [
    { id: 'faq', name: 'FAQ', icon: 'HelpCircle' },
    { id: 'knowledge', name: 'Panduan', icon: 'BookOpen' },
    { id: 'contact', name: 'Kontak', icon: 'MessageCircle' }
  ];

  const supportStats = [
    {
      id: 1,
      title: 'Rata-rata Respon',
      value: '3 menit',
      icon: 'Clock',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      id: 2,
      title: 'Tingkat Kepuasan',
      value: '98.5%',
      icon: 'Star',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    },
    {
      id: 3,
      title: 'Masalah Terselesaikan',
      value: '99.2%',
      icon: 'CheckCircle',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      id: 4,
      title: 'Support 24/7',
      value: 'Aktif',
      icon: 'Shield',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'faq':
        return <FAQSection />;
      case 'knowledge':
        return <KnowledgeBase />;
      case 'contact':
        return <ContactOptions />;
      default:
        return <FAQSection />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/5 via-background to-accent/5 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-6">
              <Icon name="Headphones" size={32} className="text-primary" />
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold text-text-primary mb-4">
              Pusat Bantuan
            </h1>
            
            <p className="text-xl text-text-secondary max-w-2xl mx-auto mb-8">
              Tim support terbaik Indonesia siap membantu Anda 24/7. 
              Dapatkan solusi cepat untuk semua kebutuhan gaming Anda.
            </p>

            {/* Quick Contact Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="default"
                size="lg"
                iconName="MessageCircle"
                iconPosition="left"
                onClick={() => window.open('https://wa.me/6281234567890?text=Halo%20Finn%20Gaming,%20saya%20butuh%20bantuan', '_blank')}
                className="bg-green-600 hover:bg-green-700"
              >
                Chat WhatsApp
              </Button>
              
              <Button
                variant="outline"
                size="lg"
                iconName="Phone"
                iconPosition="left"
                onClick={() => window.open('tel:+6281234567890')}
              >
                Telepon Langsung
              </Button>
            </div>
          </div>

          {/* Support Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {supportStats?.map((stat) => (
              <div key={stat?.id} className="bg-card border border-border rounded-xl p-4 text-center hover:shadow-gaming transition-all duration-300">
                <div className={`${stat?.bgColor} w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-3`}>
                  <Icon name={stat?.icon} size={20} className={stat?.color} />
                </div>
                <div className="text-2xl font-bold text-text-primary mb-1">
                  {stat?.value}
                </div>
                <div className="text-sm text-text-secondary">
                  {stat?.title}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {/* Tab Navigation */}
          <div className="flex justify-center mb-12">
            <div className="bg-muted p-1 rounded-lg inline-flex">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex items-center space-x-2 px-6 py-3 rounded-md text-sm font-medium transition-all duration-200 ${
                    activeTab === tab?.id
                      ? 'bg-card text-text-primary shadow-gaming'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  <Icon name={tab?.icon} size={18} />
                  <span>{tab?.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="max-w-6xl mx-auto">
            {renderTabContent()}
          </div>
        </div>
      </section>
      {/* Emergency Support Banner */}
      <section className="py-12 bg-gradient-to-r from-red-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center mb-6">
              <div className="bg-red-100 p-4 rounded-full">
                <Icon name="AlertTriangle" size={32} className="text-red-600" />
              </div>
            </div>
            
            <h2 className="text-2xl font-bold text-red-800 mb-4">
              Butuh Bantuan Segera?
            </h2>
            
            <p className="text-red-700 mb-8 max-w-2xl mx-auto">
              Jika Anda mengalami masalah urgent seperti kehilangan diamond dalam jumlah besar 
              atau masalah pembayaran yang mendesak, hubungi hotline darurat kami.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="default"
                size="lg"
                iconName="Phone"
                iconPosition="left"
                onClick={() => window.open('tel:+6281234567890')}
                className="bg-red-600 hover:bg-red-700"
              >
                Hotline Darurat
              </Button>
              
              <Button
                variant="outline"
                size="lg"
                iconName="MessageCircle"
                iconPosition="left"
                onClick={() => window.open('https://wa.me/6281234567890?text=URGENT:%20Saya%20membutuhkan%20bantuan%20segera', '_blank')}
                className="border-red-300 text-red-700 hover:bg-red-50"
              >
                WhatsApp Urgent
              </Button>
            </div>
          </div>
        </div>
      </section>
      {/* Footer CTA */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-text-primary mb-4">
            Masih Ada Pertanyaan?
          </h2>
          
          <p className="text-text-secondary mb-8 max-w-2xl mx-auto">
            Tim support Finn Gaming selalu siap membantu Anda. 
            Jangan ragu untuk menghubungi kami kapan saja!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="default"
              size="lg"
              iconName="Mail"
              iconPosition="left"
              onClick={() => window.open('mailto:pestok672@gmail.com?subject=Bantuan%20Finn%20Gaming&body=Halo%20tim%20support,%0A%0ASaya%20membutuhkan%20bantuan%20untuk:%0A%0A[Jelaskan%20masalah%20Anda%20di%20sini]', '_blank')}
            >
              Email Support
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              iconName="Send"
              iconPosition="left"
              onClick={() => window.open('https://t.me/finngaming_support', '_blank')}
            >
              Telegram
            </Button>
          </div>

          <div className="mt-8 text-sm text-text-secondary">
            <p>Email: pestok672@gmail.com | WhatsApp: +62 812-3456-7890</p>
            <p className="mt-1">Jam Operasional: 06:00 - 24:00 WIB (WhatsApp) | 24 Jam (Email)</p>
          </div>
        </div>
      </section>
      {/* Live Chat Widget */}
      <LiveChatWidget />
    </div>
  );
};

export default SupportCenter;