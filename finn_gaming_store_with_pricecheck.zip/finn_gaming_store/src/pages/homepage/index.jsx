import React from 'react';
import Header from '../../components/ui/Header';
import HeroSection from './components/HeroSection';
import GameCatalogGrid from './components/GameCatalogGrid';
import PaymentMethodsSection from './components/PaymentMethodsSection';
import TestimonialsSection from './components/TestimonialsSection';
import LiveStatsSection from './components/LiveStatsSection';
import WhatsAppFloat from './components/WhatsAppFloat';

const Homepage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <GameCatalogGrid />
        <PaymentMethodsSection />
        <TestimonialsSection />
        <LiveStatsSection />
      </main>
      <WhatsAppFloat />
      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gaming-gradient">
                  <span className="text-white font-bold text-lg">F</span>
                </div>
                <div>
                  <div className="text-xl font-bold">Finn Gaming</div>
                  <div className="text-sm text-slate-400">Store</div>
                </div>
              </div>
              <p className="text-slate-400 text-sm mb-4">
                Platform top up game terpercaya untuk gamers Indonesia. Aman, cepat, dan terjangkau.
              </p>
              <div className="flex space-x-3">
                <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-700 cursor-pointer">
                  <span className="text-xs">IG</span>
                </div>
                <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-700 cursor-pointer">
                  <span className="text-xs">TT</span>
                </div>
                <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-700 cursor-pointer">
                  <span className="text-xs">YT</span>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><a href="/game-catalog" className="hover:text-white">Katalog Game</a></li>
                <li><a href="/payment-checkout" className="hover:text-white">Cara Top Up</a></li>
                <li><a href="/account-dashboard" className="hover:text-white">Dashboard</a></li>
                <li><a href="/support-center" className="hover:text-white">Pusat Bantuan</a></li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="font-semibold mb-4">Dukungan</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><a href="/security-trust" className="hover:text-white">Keamanan</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
                <li><a href="#" className="hover:text-white">Syarat & Ketentuan</a></li>
                <li><a href="#" className="hover:text-white">Kebijakan Privasi</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold mb-4">Hubungi Kami</h4>
              <div className="space-y-3 text-sm text-slate-400">
                <div>
                  <div className="font-medium text-white">WhatsApp</div>
                  <div>+62 812-3456-7890</div>
                </div>
                <div>
                  <div className="font-medium text-white">Email</div>
                  <div>support@finngaming.id</div>
                </div>
                <div>
                  <div className="font-medium text-white">Jam Operasional</div>
                  <div>24/7 (Setiap Hari)</div>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-sm text-slate-400">
            <p>&copy; {new Date()?.getFullYear()} Finn Gaming Store. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Homepage;